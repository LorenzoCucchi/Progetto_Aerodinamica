function F=force(p,Gamma,rho,U)
[f,~]=size(Gamma);
F=0;
for i=1:f
    G_i=Gamma(i);
    r_i=p.panels(i).C-p.panels(i).B;
    V=Velocity(p,p.panels(i).P,Gamma,1);
    V=V+U';
    F=F+rho*G_i*(cross(V,r_i));
end
end