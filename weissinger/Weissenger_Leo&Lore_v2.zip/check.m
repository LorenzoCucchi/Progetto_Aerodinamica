function [V]=check(p,FX,FY,FZ,Gamma,U)
% Funzione controllo per verficare che il risultato sia coerente con le
% condizioni al contorno.
[n,m]=size(Gamma);
V=[FX*Gamma FY*Gamma FZ*Gamma]+[U(1).*ones(n,1) U(2).*ones(n,1) U(3).*ones(n,1)];
for i=1:n
    %~
    if dot(V(i,:),p.panels(i).n)>=10^-10
        error("Velocità normale al profilo non trascurabile. PANNELLO n°%d",i);
    end
end
        