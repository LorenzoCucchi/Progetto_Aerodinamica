clear all
close all
tic
%% Input iniziali
C_r =3; %Dimensione corda alla basa
C_t = 1.9; %DImensione alle estremità
b = 15.8;       % b
Delta =30/180*pi; % angolo di freccia
d = 5/180*pi ; %Angolo di diedro
N=10; %Numero di pannelli
% DATI B737
C_r=18*0.3048+8.75*0.0254; %Dimensione corda alla basa
C_t=4*0.3048+1.25*0.0254; %DImensione alle estremità
b =112*0.3048+7*0.0254;       % b
Delta =30/180*pi; % angolo di freccia
d = 5/180*pi ; %Angolo di diedro
N=5; %Numero di pannelli
alfa=4;
beta=0;
rho=1.225;
U_inf=10;
c_med=(C_r+C_t)/2;
S=b*(C_r+C_t)/2;
%% Costruisco la geometria
[X,Y,Z,p,f,M]=Geometria(b,Delta,C_r,C_t,d,N);
U = U_inf.*[cos(beta*pi/180)*cos(alfa*pi/180) ; -sin(beta*pi/180) ; cos(beta*pi/180)*sin(alfa*pi/180)];

%% Calcolo distribuzione di vorticità
[Gamma,A1,b1,FX,FY,FZ]=LinearSystem(p,f,U);
V=check(p,FX,FY,FZ,Gamma,U);
%% rappresentazione grafica del risultato della funzione
GraficoIniziale(p,Gamma,U,0)
figure (2)
G1 =reshape(Gamma(1:(M*N)),M,N)';
G2 =reshape(Gamma((M*N)+1:end),M,N)';
surf(X,Y,Z,G1),colorbar, axis equal
hold on
surf(X,-Y,Z,G2),colorbar, axis equal
axis equal
title (['\Gamma con ', '\alpha',' = ', num2str(alfa),'° ',...
    '\beta',' = ', num2str(beta),'°'])
%% riscrivo gamma come una matrice n*2M
Gamma_matrix=[];
for f=0:2*N-1
    Gamma_matrix=[Gamma_matrix;Gamma((1+f*M):(M+f*M))'];
end
Gamma_matrix=[fliplr(Gamma_matrix(N+1:end,:)) Gamma_matrix(1:N,:)];
%% calcolo portanza
dy=b/2/M;
L=0;
L2d=zeros(2*M,1);
for f=1:2*M
    for j=1:N
        %Breve discorso sulle dimensioni: Gamma(Circolazione) è m^2/s, ho
        %una L2dF pari infatti a N/m, per cui per trovare il cl_2d devo
        %dividere per la corda media.
        L2d(f)=L2d(f)+rho*U_inf*Gamma_matrix(j,f)*cos(d);
    end
    Cl_2D(f)=L2d(f)/(0.5*rho*U_inf^2*c_med);
    L=L+L2d(f)*dy;
end
Cl=L/(0.5*rho*U_inf^2*S);
%B737 Prova
h=10668;
V=926.10/3.6;
W=50000*9.8;
[~,~,~,rho]=atmosisa(h);
Cl2=W/(0.5*rho*V^2*S);

y_vect=linspace(-b/2,b/2,2*M);
figure(3)
plot(y_vect,Cl_2D,'b','linewidth',1);
grid on
title (['CL_2_d con ', '\alpha',' = ', num2str(alfa),'° ',...
    '\beta',' = ', num2str(beta),'°',' Freccia',' = ', num2str(Delta*180/pi),'°'])
%% Calcolo delle froze:
% stavo cercando di utilizzare ciò che è scritto nelle vecchie slide, ma
% nulla da fare, bho ho numerosi dubbi
F=force(p,Gamma,rho,U);
b2w=[cos(alfa*pi/180)*cos(beta*pi/180) -sin(beta*pi/180) sin(alfa*pi/180)*cos(beta*pi/180) ;...
           cos(alfa*pi/180)*sin(beta*pi/180)  cos(beta*pi/180) sin(alfa*pi/180)*sin(beta*pi/180) ;...
           -sin(alfa*pi/180)               0         cos(alfa*pi/180)        ];
F_wind=b2w*F';   
%% Calcolo velocità indotta
Time=toc;
fprintf("Time: %.3f s \n",Time);

