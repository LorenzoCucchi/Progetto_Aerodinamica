function [V]=BiotSavar(p1,p2,c)
r0=p2-p1;
r1=c-p1;
r2=c-p2;
R_cross=cross(r1,r2);
V=1/4/pi*dot(r0,(r1/norm(r1)-r2/norm(r2)))*R_cross/norm(R_cross)^2;
end