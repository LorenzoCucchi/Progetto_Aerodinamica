function [X,Y,Z,p,f,M]=Geometria(b,Delta,C_r,C_t,d,N)
% INPUT
% b : apertura alare
% Delta : angolo di freccia
% C_r : lunghezza della corda alla radice
% C_t : lunghezza della corda all'estremità alare
% d : angolo di diero
% N : numero di suddivisioni lungo la corda
% Definisco alcuni parametri
c_med=(C_r+C_t)/2;
M=round(N*b/2/c_med,0);
% Definiscono le funzioni per il calcolo delle coordinate
fprintf("Ricerca dei Punti di Estremità.... \n");
X_r=@(i) C_r./N.*i;
X_t=@(i) C_t./N.*i;
tan_alfa=@(i) (b./2.*tan(Delta)+X_t(i)-X_r(i)).*2./b;
X_pij=@(i,j) X_r(i)+b./2./M.*j.*tan_alfa(i);
Y_pij=@(j) b./2./M.*j;
Z_pij=@(j) b./2./M.*j.*tan(d);
A=[];
X=[];
Y=[];
Z=[];
for i=0:N
    for j=0:M
        A=[A;X_pij(i,j) Y_pij(j) Z_pij(j)];
        X(i+1,j+1)=X_pij(i,j);
        Y(i+1,j+1)=Y_pij(j);
        Z(i+1,j+1)=Z_pij(j);
        
    end
end
A=[A;A(:,1) -A(:,2) A(:,3)];
%Calcolo la matrice p per calcolare tutti i pannelli con le varie
%informazioni
p=struct;
f=1;
t=1;
i=1;
fprintf("Creazione dei pannelli...\n");
while i<=((N+1)*(M+1)-M-2)
    %Controllo se sono arrivato al bordo
    if i/(M+1)==t
        t=t+1;
        i=i+1;
    end
    p.panels(f).P4=[A(i,1) A(i,2) A(i,3)];
    p.panels(f).P3=[A(i+M+1,1) A(i+M+1,2) A(i+M+1,3)];
    p.panels(f).P2=[A(i+M+2,1) A(i+M+2,2) A(i+M+2,3)];
    p.panels(f).P1=[A(i+1,1) A(i+1,2) A(i+1,3)];
    % Cslcolo le velocità nei vari punti
    Xb=(p.panels(f).P3(1)-p.panels(f).P4(1))/4+p.panels(f).P4(1);
    p.panels(f).A=[Xb*1000 p.panels(f).P4(2) p.panels(f).P4(3)];
    p.panels(f).B=[Xb p.panels(f).P4(2) p.panels(f).P4(3)];
    Xc=(p.panels(f).P2(1)-p.panels(f).P1(1))/4+p.panels(f).P1(1);
    p.panels(f).D=[Xc*1000 p.panels(f).P1(2) p.panels(f).P1(3)];
    p.panels(f).C=[Xc p.panels(f).P1(2) p.panels(f).P1(3)];
    %Normale
    p.panels(f).n=[0 -sin(d) cos(d)];
    %Punto di Controllo P
    l=sqrt((p.panels(f).P1(3)-p.panels(f).P4(3))^2+...
        (p.panels(f).P1(2)-p.panels(f).P4(2))^2)/2;
    Xb1=(p.panels(f).P3(1)-p.panels(f).P4(1))*3/4+p.panels(f).P4(1);
    Xc1=(p.panels(f).P2(1)-p.panels(f).P1(1))*3/4+p.panels(f).P1(1);
    tan_gamma=(Xc1-Xb1)/2;
    Z_pc=p.panels(f).P4(3)+l*sin(d);
    Y_pc=p.panels(f).P4(2)+b/4/M;
    X_pc=tan_gamma+Xb1;
    p.panels(f).P=[X_pc Y_pc Z_pc];
    f=f+1;
    i=i+1;
end
f=f-1;
%ora devo calcolare l'altra semiala; per farlo basta aggiungere gli stessi
%pannelli con tutte le y invertite
for i=1:f
    p.panels(f+i).P4(1)=p.panels(i).P1(1);
    p.panels(f+i).P4(2)=-p.panels(i).P1(2);
    p.panels(f+i).P4(3)=p.panels(i).P1(3);
    p.panels(f+i).P3(1)=p.panels(i).P2(1);
    p.panels(f+i).P3(2)=-p.panels(i).P2(2);
    p.panels(f+i).P3(3)=p.panels(i).P2(3);
    p.panels(f+i).P2(1)=p.panels(i).P3(1);
    p.panels(f+i).P2(2)=-p.panels(i).P3(2);
    p.panels(f+i).P2(3)=p.panels(i).P3(3);
    p.panels(f+i).P1(1)=p.panels(i).P4(1);
    p.panels(f+i).P1(2)=-p.panels(i).P4(2);
    p.panels(f+i).P1(3)=p.panels(i).P4(3);
    p.panels(f+i).A(1)=p.panels(i).D(1);
    p.panels(f+i).A(2)=-p.panels(i).D(2);
    p.panels(f+i).A(3)=p.panels(i).D(3);
    p.panels(f+i).B(1)=p.panels(i).C(1);
    p.panels(f+i).B(2)=-p.panels(i).C(2);
    p.panels(f+i).B(3)=p.panels(i).C(3);
    p.panels(f+i).C(1)=p.panels(i).B(1);
    p.panels(f+i).C(2)=-p.panels(i).B(2);
    p.panels(f+i).C(3)=p.panels(i).B(3);
    p.panels(f+i).D(1)=p.panels(i).A(1);
    p.panels(f+i).D(2)=-p.panels(i).A(2);
    p.panels(f+i).D(3)=p.panels(i).A(3);
    p.panels(f+i).P(1)=p.panels(i).P(1);
    p.panels(f+i).P(2)=-p.panels(i).P(2);
    p.panels(f+i).P(3)=p.panels(i).P(3);
    p.panels(f+i).n(1)=p.panels(i).n(1);
    p.panels(f+i).n(2)=-p.panels(i).n(2);
    p.panels(f+i).n(3)=p.panels(i).n(3);
end
f=f*2;
end