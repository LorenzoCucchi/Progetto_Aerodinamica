clear all
close all
%% Input iniziali
C_r = 2.9; %Dimensione corda alla basa
C_t = 1; %DImensione alle estremità
b = 15.8;       % b
Delta =5.2/180*pi; % angolo di freccia
d = 2.9/180*pi ; %Angolo di diedro
N=3; %Numero di pannelli
alfa=10*pi/180; 
beta=10*pi/180;
%% Costruisco la geometria
[X,Y,Z,p,f,M]=Geometria(b,Delta,C_r,C_t,d,N);
U = [cos(beta)*cos(alfa) ; -sin(beta) ; cos(beta)*sin(alfa)];
%% rappresentazione grafica del risultato della funzione
%GraficoIniziale(p,f)
[Gamma,A1,b1]=LinearSystem(p,f,U);
figure (2)
G1 =reshape(Gamma(1:(M*N)),M,N)';
G2 =reshape(Gamma((M*N)+1:end),M,N)';
surf(X,Y,Z,G1),colorbar, axis equal
hold on
surf(X,-Y,Z,G2),colorbar, axis equal
axis equal
Time=cputime/1000;
fprintf("Time: %.3f s \n",Time);