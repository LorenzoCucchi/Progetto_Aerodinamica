function GraficoIniziale(p,f)
fprintf("Generazione Figura\n");
for i=1:f
    str=cellstr(num2str(i));
    figure (1)
    XP=[p.panels(i).P1(1) p.panels(i).P2(1) p.panels(i).P3(1) p.panels(i).P4(1) p.panels(i).P1(1)];
    YP=[p.panels(i).P1(2) p.panels(i).P2(2) p.panels(i).P3(2) p.panels(i).P4(2) p.panels(i).P1(2)];
    ZP=[p.panels(i).P1(3) p.panels(i).P2(3) p.panels(i).P3(3) p.panels(i).P4(3) p.panels(i).P1(3)];
    %Punto di Controllo
    plot3(p.panels(i).P(1),p.panels(i).P(2),p.panels(i).P(3),'*','color','b');
    hold on
    %plot3(p.panels(i).A(1)/100,p.panels(i).A(2),p.panels(i).A(3),'+','color','r');    
    plot3(p.panels(i).B(1),p.panels(i).B(2),p.panels(i).B(3),'+','color','r');    
    plot3(p.panels(i).C(1),p.panels(i).C(2),p.panels(i).C(3),'+','color','r');
    quiver3(p.panels(i).P(1),p.panels(i).P(2),p.panels(i).P(3),p.panels(i).n(1),p.panels(i).n(2),p.panels(i).n(3),'color','g');
    %plot3(p.panels(i).D(1)/100,p.panels(i).D(2),p.panels(i).D(3),'+','color','r');    
    %MarkerType
    plot3(XP,YP,ZP,'linewidth',0.1,'color','k');
    hold on
    text(p.panels(i).P(1),p.panels(i).P(2),p.panels(i).P(3),str)
end
grid on
axis equal